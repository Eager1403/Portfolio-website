function showGreeting() {
    const hour = new Date().getHours();
    let message = "Welcome!";
    if (hour < 12) message = "Good Morning, Ayubu!";
    else if (hour < 18) message = "Good Afternoon, Ayubu!";
    else message = "Good Evening, Ayubu!";
    alert(message);
  }
  
  function toggleDetails(button) {
    const details = button.nextElementSibling;
    details.classList.toggle("hidden");
  }
  
  // Dark mode toggle (add a button on your site to call this)
  function toggleDarkMode() {
    document.body.classList.toggle("dark-mode");
  }
  
  // Form validation example
  document.getElementById("contactForm")?.addEventListener("submit", function (e) {
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const emailRegex = /^[^@]+@[^@]+\.[a-z]{2,}$/;
    const phoneRegex = /^\d{10}$/;
    if (!emailRegex.test(email) || !phoneRegex.test(phone)) {
      alert("Invalid email or phone number!");
      e.preventDefault();
    }
  });
  