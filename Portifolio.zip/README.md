# Ayubu's Portfolio Website

## Tools Used
- HTML5
- CSS3
- JavaScript

## Key Features
- Responsive layout
- Contact and Survey forms with validation
- Dark/Light mode toggle
- Project showcase with toggle details

## Challenges Faced
- Form validation took time to debug, solved using Regex.
- Layout alignment was tricky—solved using CSS Grid and Flexbox.

## Live Demo
[GitHub Pages link here]
